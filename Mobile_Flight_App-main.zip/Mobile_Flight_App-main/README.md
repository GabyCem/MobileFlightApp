# Mobile_Flight_App

Flight_Inspection_App Contributes: Tamir Akian , Gabriel Cembal.
Description: "Mobile_Flight_App" is an application which controls the plane movement and speed through an android mobile phone.

First time running:

download the flight gear simulator. You can download it in the link below: http://www.flightgear.org

Run the Flight gear simulator and choose the data directory in the given box. The path is: C:\Program Files\FlightGear 2020.3.6\data Restart the simulator.

In the Flight gear simulator go to the settings, in the command line below type: --telnet=socket,in,10,127.0.0.1,6400,tcp

Using Fligh_Mobile_App:

You can controll the rudder and the throttle with 2 seek bars. The throttle is the vertical seek bar and the horizontal one is the rudder.

In the middle is the joystick.

Joystick- The joystick is bound to the values of the elevator and the aileron. It moves alone with the change of the values.

Documentation In the following link you will find documentation on the UML parts and the connections between the various departments.

The link to the UML: https://ibb.co/Bg4GvpX

The link to the explenation video: https://storyxpress.co/video/kqieyx1ym0ua2d6lr
